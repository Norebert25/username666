import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-distorted',
  templateUrl: './home-distorted.component.html',
  styleUrls: ['./home-distorted.component.sass', '../home/home.component.sass']
})
export class HomeDistortedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
