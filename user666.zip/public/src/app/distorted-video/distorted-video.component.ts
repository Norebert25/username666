import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-distorted-video',
  templateUrl: './distorted-video.component.html',
  styleUrls: ['./distorted-video.component.sass','../video/video.component.sass']
})
export class DistortedVideoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
